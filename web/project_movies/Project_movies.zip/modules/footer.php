<?php
?>
    <footer class="container-fluid">
        <p>Movie Database Inc. @ public content</p>
        <br>
        <p>Database accessed <?php echo date("Y/m/d"); ?> </p>
    </footer>

