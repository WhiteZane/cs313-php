<?php
?>
<div id="mainnav" >
<nav>
    <ul>
        <li><a href="./index.php">Home </a></li>
        <li><a href="./allMovies.php">All Movies </a></li>
        <li><a href="./add_movie.php">Add Movie </a></li>
        <li><a href="./edit_movies.php">Edit Movies </a></li>
        
    </ul>
    
</nav>
    </div>

